import time

def handler(event, context):
    return int(time.time())
